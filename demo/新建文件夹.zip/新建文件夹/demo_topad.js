if ((navigator.userAgent.match(/(iPhone|iPod|Android|ios|iOS|iPad|Backerry|WebOS|Symbian|Windows Phone|Phone)/i))) { 

}else{
document.write('<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>');
document.write('<ins class="adsbygoogle"');
document.write('style="display:inline-block;width:468px;height:60px"');
document.write('data-ad-client="ca-pub-7515443544894528"');
document.write('data-ad-slot="3076591508"></ins>');
document.write('<script>');
document.write('(adsbygoogle = window.adsbygoogle || []).push({});');
document.write('</script>');

//document.write("<script type=\"text/javascript\">google_ad_client = \"ca-pub-7515443544894528\";google_ad_slot = \"3076591508\";google_ad_width = 468;google_ad_height = 60;</script>");
//document.write("<script type=\"text/javascript\" src=\"//pagead2.googlesyndication.com/pagead/show_ads.js\"></script>");
}